valores = []
valores.append(8)
valores.append(16)
valores.append(32)

#for v in valores:
    #print(f'{v}...')

for c, v in enumerate(valores):
    print(f'Na posição {c} encontrei o valor {v}')
print(f'Cheguei no fim da lista!')