for time1 in ('Flamengo', 'Fluminence', 'Botafogo', 'Vasco', 'America - RJ'):
    for time2 in ('Flamengo', 'Fluminence', 'Botafogo', 'Vasco', 'America - RJ'):
        if time1 != time2:
            print(time1, 'x', time2)