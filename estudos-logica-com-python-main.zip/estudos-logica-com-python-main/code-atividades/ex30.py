#VARIÁVEL LOCAL
def funcao():
    variavel_local = "Estou dentro da funcao"
    print(variavel_local) #ISSO CAUSARÁ UM ERRO

funcao()