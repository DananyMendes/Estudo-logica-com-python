s = 'rato'
r = ''

for item in s:
    r = item.upper() + r
print(r)