a = [2, 3, 5, 6]
b = a[:] #copia de a dentro de b
b[2] = 8
print(f'Lista A: {a}')
print(f'Lista A: {b}')