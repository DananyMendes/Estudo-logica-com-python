import math
num = int(input("Digite um número:"))
print(f"O fatorial {num} é", math.factorial(num))