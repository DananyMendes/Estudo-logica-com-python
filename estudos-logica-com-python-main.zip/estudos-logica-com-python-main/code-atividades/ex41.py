#ATV
def printMax(a, b):
    if a > b:
        print(a, 'é o maior')
    elif a==b:
        print(a, 'é igual a', b)
    else:
        print(b, 'é o maior')

printMax(3, 4)