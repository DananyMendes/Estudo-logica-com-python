#Escrevendo em um arquivo

nome = input('Qual é o seu nome?')
print(f"Olá, {nome}!")

