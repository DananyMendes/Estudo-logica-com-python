def minuscula(texto):
    return texto.lower()

texto = "PYTHON"
texto_convertido = minuscula(texto)
print(texto_convertido)