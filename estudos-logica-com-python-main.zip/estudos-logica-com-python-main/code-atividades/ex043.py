numero = int(input("Digite um número:"))
print(f"O fatorial desse número é", math.factorial(numero))