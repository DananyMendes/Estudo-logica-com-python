frutas = {'maçãs': 1, 'bananas': 2, 'peras': 3, 'laranjas': 4 }
frutas['uvas'] = 15

print(frutas)