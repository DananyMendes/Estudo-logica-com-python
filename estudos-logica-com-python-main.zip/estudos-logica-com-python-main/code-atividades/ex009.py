# Desenvolva um programa que realize a validação de dados.
# O script deve ler o sexo de uma pessoa, mas só aceitar os valores 'M' ou 'F'.
# Caso esteja errado, peça a digitação novamente até ter um valor válido.

#Estrutura de Repetição While - Exercícios de Fixação

cont = 1
s = 0

while cont <= 6:
    s += cont
    cont += 2
print(s)