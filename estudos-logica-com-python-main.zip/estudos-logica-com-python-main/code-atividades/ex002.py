#Crie um programa que realize a soma entre dois números
#Crie um programa que leia uma variável e retorne diversas informações sobre ela

x = 50
y = 30

a = "Eu sou uma String"
b = 1.70

print("A soma de x e y: ", x + y)
print("Qual o seu Tipo?", type(a))
print("Qual o seu Tipo?", type(b))
print("Qual o seu Tipo?", type(x))
