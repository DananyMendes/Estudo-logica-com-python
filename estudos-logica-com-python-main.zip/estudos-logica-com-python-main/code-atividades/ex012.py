i = 1
a = 5
while i <= 3:
    a = a*2 - 3
    i += 1
print(a)