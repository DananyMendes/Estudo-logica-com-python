#Declaração de variáveis
#Atribuição de valores
#Nomes de variáveis(nome, tipo, xp)
#Reatribuição de valores(xp = xp + 1500)
#Tipos de dados(Str, Str, Int)

nome = "Gandalf"
tipo = "Mago"
xp = 1500

xp = xp + 1500

print("Seu personagem é,", nome,"do tipo, ", tipo,"e xp:", xp)