#FUNÇÕES

#Definindo e Chamando a função

def saudacao():
    print("Olá, Mundo!")
saudacao()